# Test-api project
This is a test project given by Naji MHAMDHI to practise :
- Formik for forms
- Easy Peasy for stores
- Ag grid for grids
- A Spring backend
- A postgreSQL database to save and use data

## To run this project
```
mvn clean install
```
You need a postgreSQL server running and a database named `test-api` with username `postgres` and password `postgres`.
