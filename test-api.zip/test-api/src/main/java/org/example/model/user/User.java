package org.example.model.user;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.example.model.enums.Gender;

import java.sql.Timestamp;

@Entity
@Data
@NoArgsConstructor
@Table(name = "users")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(name = "id", example = "1", required = false)
    private Long id;
    @Schema(name = "name", example = "John", required = true)
    private String name;
    @Schema(name = "firstname", example = "Feur", required = true)
    private String firstname;
    @Schema(name = "age", example = "42", required = true)
    private Integer age;
    @Schema(name = "gender", example = "MALE", required = true)
    @Enumerated(EnumType.STRING)
    private Gender gender;

    public User(String name, String firstname, Integer age, Gender gender) {
        this.name = name;
        this.firstname = firstname;
        this.age = age;
        this.gender = gender;
    }
}
