package org.example.service;

import org.example.model.user.DTO.CreateUserDTO;
import org.example.model.user.DTO.UserDTO;
import org.example.model.user.User;

import java.util.List;

public interface IUserService {
    List<User> getUsers();
    User getUser(Long id);
    User createUser(CreateUserDTO createUserDTO);
    User updateUser(UserDTO userDTO);
    User deleteUser(Long id);
}
