package org.example.service;

import org.example.model.user.DTO.CreateUserDTO;
import org.example.model.user.DTO.UserDTO;
import org.example.model.user.User;
import org.example.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService implements IUserService {
    private final UserRepository userRepository;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public List<User> getUsers() {
        return userRepository.findAll();
    }

    @Override
    public User getUser(Long id) {
        return userRepository.findUserById(id);
    }

    @Override
    public User createUser(CreateUserDTO createUserDTO) {
        User user = new User(
                createUserDTO.getName(),
                createUserDTO.getFirstname(),
                createUserDTO.getAge(),
                createUserDTO.getGender()
        );
        userRepository.save(user);
        return user;
    }

    public User updateUser(UserDTO userDTO) {
        User user = userRepository.findUserById(userDTO.getId());
        if (user != null) {
            user.setName(userDTO.getName());
            user.setFirstname(userDTO.getFirstname());
            user.setAge(userDTO.getAge());
            user.setGender(userDTO.getGender());

            userRepository.save(user);
            return user;
        }
        return null;
    }

    @Override
    public User deleteUser(Long id) {
        User user = userRepository.findUserById(id);
        if (user != null) {
            userRepository.delete(user);
            return user;
        }
        return null;
    }
}
