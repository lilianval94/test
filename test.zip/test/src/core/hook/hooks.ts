import { createTypedHooks } from 'easy-peasy';
import {StoreModel} from "../model/store/StoreModel.ts";

const typedHooks = createTypedHooks<StoreModel>();

export const useStoreActions = typedHooks.useStoreActions;
export const useStoreDispatch = typedHooks.useStoreDispatch;
export const useStoreState = typedHooks.useStoreState;