import {action, createStore, thunk} from "easy-peasy";
import {StoreModel} from "../model/store/StoreModel.ts";
import {createUser, deleteUser, getUsers, updateUser} from "../service/userService.ts";

export const store = createStore<StoreModel>({
    users: [],

    setUsers: action((state, users) => {
        state.users = users;
    }),

    addUser: action((state, user) => {
        state.users.push(user)
    }),

    removeUser: action((state, id) => {
        state.users = state.users.filter(userFiltered => userFiltered.id !== id)
    }),

    fetchUsers: thunk(async (actions) => {
        const users = await getUsers();
        if (users) {
            actions.setUsers(users);
        }
    }),

    createUser: thunk(async (actions, user) => {
        const user_created = await createUser(user);
        if (user_created) {
            actions.addUser(user_created);
        }
    }),

    updateUser: thunk(async (_actions, user) => {
        await updateUser(user)
    }),

    deleteUser: thunk(async (actions, id) => {
        const user_removed = await deleteUser(id);
        if (user_removed) {
            actions.removeUser(id);
        }
    })
});