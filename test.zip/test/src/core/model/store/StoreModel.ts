import {CreateUserDTO} from "../user/CreateUserDTO.ts";
import {Action, Thunk} from "easy-peasy";
import {User} from "../user/User.ts";
import {UpdateUserDTO} from "../user/UpdateUserDTO.ts";

export interface StoreModel {
    users: User[];

    setUsers: Action<StoreModel, User[]>;
    addUser: Action<StoreModel, User>;
    removeUser: Action<StoreModel, number>;

    fetchUsers: Thunk<StoreModel>;
    createUser: Thunk<StoreModel, CreateUserDTO>;
    updateUser: Thunk<StoreModel, UpdateUserDTO>;
    deleteUser: Thunk<StoreModel, number>;
}