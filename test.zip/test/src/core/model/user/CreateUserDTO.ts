import {Gender} from "../enums/Gender.ts";

export interface CreateUserDTO {
    name: string;
    firstname: string;
    age: number;
    gender: Gender;
}