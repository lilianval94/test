import {Gender} from "../enums/Gender.ts";

export interface UpdateUserDTO {
    id: number;
    name: string;
    firstname: string;
    age: number;
    gender: Gender;
}