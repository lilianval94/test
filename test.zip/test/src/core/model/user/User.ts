import {Gender} from "../enums/Gender.ts";

export interface User {
    id: number;
    name: string;
    firstname: string;
    age: number;
    gender: Gender;
}