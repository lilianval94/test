// Ag grid
export const pagination = true;
export const paginationPageSize = 50;
export const paginationPageSizeSelector = [50, 1000];
export const defaultColDef = { flex: 1 };