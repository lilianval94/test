export function isValidName(name: string): boolean {
    const regex = /^[A-Za-zÀ-ÖØ-öø-ÿ]+$/;
    const minLength = 2;
    const maxLength = 50;
    return regex.test(name) && name.length >= minLength && name.length <= maxLength;
}
