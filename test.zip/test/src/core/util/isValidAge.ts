export function isValidAge(age: number): boolean {
    return age >= 0 && age <= 120;
}
