import {CreateUserDTO} from "../model/user/CreateUserDTO.ts";
import axios from "axios";
import {UpdateUserDTO} from "../model/user/UpdateUserDTO.ts";
import {User} from "../model/user/User.ts";

const API_URL = "http://localhost:8080/api/users"

export const getUsers = async (): Promise<User[] | undefined> => {
    try {
        const response = await axios.get<User[]>(`${API_URL}`);
        return response.data;
    } catch (error) {
        console.error("getUsers:", error);
    }
}

export const getUser = async (id: number): Promise<User | undefined> => {
    try {
        const response = await axios.get<User>(`${API_URL}/${id}`);
        return response.data;
    } catch (error) {
        console.error("getUser:", error);
    }
}

export const createUser = async (user: CreateUserDTO): Promise<User | undefined> => {
    try {
        const response = await axios.post<User>(`${API_URL}`, user);
        console.log("createUser ->", response.data);
        return response.data;
    } catch (error) {
        console.error("createUser:", error);
    }
}

export const updateUser = async (user: UpdateUserDTO): Promise<User | undefined> => {
    try {
        const response = await axios.put<User>(`${API_URL}/${user.id}`, user);
        console.log("updateUser ->", response.data);
        return response.data;
    } catch (error) {
        console.error("updateUser:", error);
    }
}

export const deleteUser = async (id: number): Promise<User | undefined> => {
    try {
        const response = await axios.delete<User>(`${API_URL}/${id}`);
        console.log("deleteUser ->", response.data);
        return response.data;
    } catch (error) {
        console.error("deleteUser:", error);
    }
}