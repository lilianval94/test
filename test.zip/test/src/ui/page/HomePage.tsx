import UserForm from "../component/UserForm.tsx";
import {UserGrid} from "../component/UserGrid.tsx";

export const HomePage = () => {
    return (
        <div>
            <UserForm />
            <UserGrid />
        </div>
    )
}