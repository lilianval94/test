export const RedAsterisk = () => {
    return (
        <span className="not-valid-field-form">*</span>
    )
}
