import {Field, Form, Formik, FormikErrors} from 'formik';
import {Gender} from "../../core/model/enums/Gender.ts";
import "../style/formStyles.css"
import {CreateUserDTO} from "../../core/model/user/CreateUserDTO.ts";
import {isValidName} from "../../core/util/isValidName.ts";
import {isValidAge} from "../../core/util/isValidAge.ts";
import {useStoreActions} from "../../core/hook/hooks.ts";
import {RedAsterisk} from "./RedAsterisk.tsx";

interface FormValues {
    name: string;
    firstname: string;
    age: number;
    gender: Gender;
}

const initialValues: FormValues = {
    name: "Valentin",
    firstname: "Lilian",
    age: 23,
    gender: Gender.MALE,
}

const UserForm = () => {
    const createUser = useStoreActions((state) => state.createUser)

    const onSubmit = (values: FormValues) => {
        try {
            const user: CreateUserDTO = {
                name: values.name,
                firstname: values.firstname,
                age: values.age,
                gender: values.gender,
            }
            createUser(user)
        } catch (error) {
            console.log(error)
        }
    }

    const validate = (values: FormValues) => {
        const errors: FormikErrors<FormValues> = {};

        if (!values.name) {
            errors.name = 'Required';
        } else if (!isValidName(values.name)) {
            errors.name = 'Invalid name';
        }

        if (!values.firstname) {
            errors.firstname = 'Required';
        } else if (!isValidName(values.firstname)) {
            errors.firstname = 'Invalid firstname';
        }

        if (!values.age) {
            errors.age = 'Required';
        } else if (!isValidAge(values.age)) {
            errors.age = 'Invalid age';
        }

        if (!values.gender) {
            errors.age = 'Required';
        }

        return errors;
    }

    return (
        <div>
            <h1>User Form</h1>

            <Formik
                initialValues={initialValues}
                validate={validate}
                onSubmit={(values) => {
                    onSubmit(values)
                }}
            >
                {({ errors}) => (
                    <Form>
                        <div className="field-group">
                            <div className="field">
                                <label htmlFor="name">
                                    Name<RedAsterisk />
                                </label>
                                <Field type="text" name="name" placeholder="Name"/>
                                {errors.name && <div className="not-valid-field-form">{errors.name}</div>}
                            </div>

                            <div className="field">
                                <label htmlFor="firstname">
                                    Firstname<RedAsterisk />
                                </label>
                                <Field type="text" name="firstname" placeholder="Firstname"/>
                                {errors.firstname && <div className="not-valid-field-form">{errors.firstname}</div>}
                            </div>

                            <div className="field">
                                <label htmlFor="age">
                                    Age<RedAsterisk />
                                </label>
                                <Field type="number" name="age" placeholder="Age"/>
                                {errors.age && <div className="not-valid-field-form">{errors.age}</div>}
                            </div>

                            <div className="field">
                                <label htmlFor="gender">
                                    Gender<RedAsterisk />
                                </label>
                                <Field as="select" name="gender" placeholder="Gender" >
                                    {Object.values(Gender).map((value) => (
                                        <option key={value} value={value}>
                                            {value}
                                        </option>
                                    ))}
                                </Field>
                                {errors.gender && <div className="not-valid-field-form">{errors.gender}</div>}
                            </div>

                        </div>

                        <button type="submit" className="submit-button">Submit</button>
                    </Form>
                )}
            </Formik>
        </div>
    );
};

export default UserForm