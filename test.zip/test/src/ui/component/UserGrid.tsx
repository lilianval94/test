'use client';
import {useEffect, useState} from "react";
import {AllCommunityModule, ModuleRegistry} from "ag-grid-community";
import {AgGridReact} from "ag-grid-react";
import "../style/gridStyles.css"
import {Gender} from "../../core/model/enums/Gender.ts";
import {useStoreActions, useStoreState} from "../../core/hook/hooks.ts";
import {User} from "../../core/model/user/User.ts";
import {UpdateUserDTO} from "../../core/model/user/UpdateUserDTO.ts"
import {CellEditingStoppedEvent} from "ag-grid";
import {CellClassParams} from "ag-grid/dist/lib/entities/colDef";
import {defaultColDef, pagination, paginationPageSize, paginationPageSizeSelector} from "../../core/util/constants.ts";

ModuleRegistry.registerModules([AllCommunityModule]);

export const UserGrid = () => {
    const users: User[] = useStoreState((state) => state.users)
    const fetchUsers = useStoreActions((actions) => actions.fetchUsers)
    const updateUser = useStoreActions((actions) => actions.updateUser)
    const deleteUser = useStoreActions((actions) => actions.deleteUser)

    const onCellEditingStopped = (event: CellEditingStoppedEvent) => {
        try {
            const values = event.data
            const user: UpdateUserDTO = {
                id: values.id,
                name: values.name,
                firstname: values.firstname,
                age: values.age,
                gender: values.gender,
            }
            updateUser(user)
    } catch (error) {
            console.log(error)
        }
    }

    const DeleteButton = (params: CellClassParams) => {
        const handleClick = () => {
            const idToDelete = params.data.id
            const updatedData = rowData.filter(row => row.id !== idToDelete)
            setRowData(updatedData)
            deleteUser(idToDelete)
        }
        return (
            <button style={{color: "white"}} onClick={handleClick}>Delete</button>
        )
    };

    const [rowData, setRowData] = useState<User[]>([]);
    const [colDefs] = useState([
        {
            field: "id",
            filter: true,
            sort: "asc"
        },
        {
            field: "name",
            editable: true,
            filter: true,
            cellEditor: 'agTextCellEditor',
        },
        {
            field: "firstname",
            editable: true,
            filter: true,
            cellEditor: 'agTextCellEditor',
        },
        {
            field: "age",
            editable: true,
            filter: true,
            cellEditor: 'agNumberCellEditor',
        },
        {
            field: "gender",
            editable: true,
            filter: true,
            cellEditor: 'agSelectCellEditor',
            cellEditorParams: {
                values: Object.values(Gender),
            },
        },
        {
            field: "delete",
            cellRenderer: DeleteButton,
        }
    ]);

    useEffect(() => {
        fetchUsers();
    }, [fetchUsers]);

    useEffect(() => {
        if (users) {
            setRowData(users)
        }
    }, [users]);

    return (
        <div className="grid-container">
            <AgGridReact
                rowData={rowData}
                columnDefs={colDefs}
                onCellEditingStopped={onCellEditingStopped}
                defaultColDef={defaultColDef}
                pagination={pagination}
                paginationPageSize={paginationPageSize}
                paginationPageSizeSelector={paginationPageSizeSelector}
            />
        </div>
    );
};