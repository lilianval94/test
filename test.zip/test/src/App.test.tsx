import { render, screen } from "@testing-library/react";
import "@testing-library/jest-dom"; // For additional matchers
import App from "./App";

describe("AG Grid component rendering", () => {
    test("renders the AG Grid container", () => {
        render(<App />);
        // Verify the grid container is rendered
        const gridContainer = screen.getByRole("grid");
        expect(gridContainer).toBeInTheDocument();
    });
});