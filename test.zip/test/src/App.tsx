import './App.css'
import {HomePage} from "./ui/page/HomePage.tsx";

function App() {

  return (
      <>
          <HomePage />
      </>
  )
}

export default App
